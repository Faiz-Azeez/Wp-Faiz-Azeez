<div class="fusion-multiple-upload-image">
	<input
		type='button'
		class='button-upload fusion-builder-upload-button'
		value='{{ fusionBuilderText.select_images }}'
		data-type="image"
		data-title="{{ fusionBuilderText.select_images }}"
		data-id="fusion-multiple-upload"
		data-element="{{ param.element_target }}"
		data-param="{{ param.param_target }}" />
</div>
