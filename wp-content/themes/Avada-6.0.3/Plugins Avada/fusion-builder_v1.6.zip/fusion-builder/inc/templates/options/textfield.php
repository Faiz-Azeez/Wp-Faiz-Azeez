<input
	type="text"
	name="{{ param.param_name }}"
	id="{{ param.param_name }}"
	value="{{ option_value }}"
	<# if ( param.placeholder ) { #>
		data-placeholder="{{ param.value }}"
	<# } #>
/>
