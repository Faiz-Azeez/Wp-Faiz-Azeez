<div
	class="fusion-datetime">
	<input
		type="text"
		data-format="yyyy-MM-dd hh:mm:ss"
		id="{{ param.param_name }}"
		class="fusion-date-time-picker"
		name="{{ param.param_name }}"
		value="{{ option_value }}"
	/>
	<div
		class="fusion-dt-picker-field add-on" >
		<i
			data-time-icon="fusiona-clock"
			data-date-icon="fusiona-calendar-plus-o">
		</i>
	</div>
</div>
