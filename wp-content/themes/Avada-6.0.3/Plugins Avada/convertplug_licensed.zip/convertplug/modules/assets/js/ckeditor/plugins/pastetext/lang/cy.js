﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastetext', 'cy', {
	button: 'Gludo fel testun plaen',
	title: 'Gludo fel Testun Plaen'
} );
