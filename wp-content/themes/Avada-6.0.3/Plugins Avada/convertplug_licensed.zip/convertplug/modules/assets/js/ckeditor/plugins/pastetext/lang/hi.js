﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastetext', 'hi', {
	button: 'पेस्ट (सादा टॅक्स्ट)',
	title: 'पेस्ट (सादा टॅक्स्ट)'
} );
