﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastetext', 'km', {
	button: 'បិទ​ភ្ជាប់​ជា​អត្ថបទ​ធម្មតា',
	title: 'បិទ​ភ្ជាប់​ជា​អត្ថបទ​ធម្មតា'
} );
